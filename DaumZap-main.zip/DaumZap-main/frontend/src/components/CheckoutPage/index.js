import CheckoutPage from './CheckoutPage';
export default CheckoutPage;
